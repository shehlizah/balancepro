<?php

define( 'REDIRECTION_VERSION', '5.5.0' );
define( 'REDIRECTION_MIN_WP', '6.4' );
define( 'REDIRECTION_BUILD', 'eff218e8a6050e14b616f8d6629e0ae4' );
